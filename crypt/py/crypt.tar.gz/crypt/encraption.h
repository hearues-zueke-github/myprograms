void algorithmEncrypt(unsigned char *array_in, int array_length_in, unsigned char *array_crypt, int array_length_crypt);
void algorithmDecrypt(unsigned char *array_in, int array_length_in, unsigned char *array_crypt, int array_length_crypt);
