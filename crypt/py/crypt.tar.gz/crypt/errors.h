#define ERR_WRONG_USAGE 1
#define ERR_NO_MODE 2
#define ERR_NO_MEM 3
#define ERR_FILE_NOT_FOUND 4


